#include "pch.h"
#include "GameManager.h"


GameManager::GameManager()
{
}


GameManager::~GameManager()
{
}


GameManager* GameManager::Getlnstance()
{
	static GameManager g;
	return &g; 
}
