#include "pch.h"
#include "SoundEvent.h"


SoundEvent::SoundEvent() :sourceVoice(nullptr)
{
}


SoundEvent::~SoundEvent()
{
}
