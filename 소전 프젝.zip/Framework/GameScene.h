#pragma once
#include "Scene.h"
#include "Enemy.h"
#include "Player.h"
class GameScene :
	public Scene
{
public:
	GameScene();
	~GameScene();


	void Initialize();
};

